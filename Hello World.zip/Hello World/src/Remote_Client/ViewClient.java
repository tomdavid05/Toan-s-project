package Remote_Client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Font;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class ViewClient {

	private static Socket socket;
//	DataInputStream dis = new DataInputStream(socket.getInputStream());
//	DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
	private JFrame frame;
private JLabel lblConnectedTo;

	/**
	 * Launch the application.
	 */

//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ViewClient window = new ViewClient();
////					controlServer();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}});
//	}

	/**
	 * Create the application.
	 */
	public ViewClient() {
		controlServer();
		initialize();
		this.frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 524, 126);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);

		JButton bt_shutdown = new JButton("shutdown");
		bt_shutdown.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure ???");
					if (confirm == JOptionPane.NO_OPTION)
						return;

					String cmd = e.getActionCommand();
					DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
					dos.writeUTF(cmd);
					dos.flush();
//					dos.close();
				} catch (Exception e2) {
					// TODO: handle exception
					System.out.println(e2.getMessage());
				}

			}
		});
		bt_shutdown.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_shutdown.setBounds(21, 51, 109, 27);
		frame.getContentPane().add(bt_shutdown);

		JButton bt_restart = new JButton("restart");
		bt_restart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure ???");
					if (confirm == JOptionPane.NO_OPTION)
						return;

					String cmd = e.getActionCommand();
					DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
					dos.writeUTF(cmd);
					dos.flush();
//					dos.close();
				} catch (Exception e2) {
					// TODO: handle exception
					System.out.println(e2.getMessage());
				}
			}
		});
		bt_restart.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_restart.setBounds(140, 51, 104, 27);
		frame.getContentPane().add(bt_restart);

		JButton bt_screenshot = new JButton("screenshot");
		bt_screenshot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String cmd = e.getActionCommand();
					DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
					DataInputStream dis = new DataInputStream(socket.getInputStream());
					dos.writeUTF(cmd);
					dos.flush();
					int size = dis.readInt();
					byte[] imageBytes = new byte[size];
					dis.readFully(imageBytes);

					JFileChooser jfc = new JFileChooser();
					jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					int check = jfc.showOpenDialog(frame);
					if (check == JFileChooser.APPROVE_OPTION) {
						BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
						
						String path = jfc.getSelectedFile().getAbsolutePath() + "\\screenshot4.png";
						Path filePath = Paths.get(path);
						File outputFile = new File(path);
						 ImageIO.write(image, "png", outputFile);
						JOptionPane.showMessageDialog(frame, "Done!");

					}
					dos.close();
				} catch (Exception e2) {
					// TODO: handle exception
					System.out.println(e2.getMessage());
				}

			}
		});
		bt_screenshot.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_screenshot.setBounds(254, 51, 117, 27);
		frame.getContentPane().add(bt_screenshot);

		JButton bt_cancel = new JButton("cancel");
		bt_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String cmd = e.getActionCommand();
					DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
					dos.writeUTF(cmd);
					dos.flush();
//					dos.close();
				} catch (Exception e2) {
					// TODO: handle exception
					System.out.println(e2.getMessage());
				}
			}
		});
		bt_cancel.setFont(new Font("Tahoma", Font.BOLD, 15));
		bt_cancel.setBounds(381, 51, 103, 27);
		frame.getContentPane().add(bt_cancel);
		
		 lblConnectedTo = new JLabel("Connected to IPv4 Address: ");
		lblConnectedTo.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblConnectedTo.setBounds(21, 11, 479, 32);
		try {
			DataInputStream dis = new DataInputStream(socket.getInputStream());
		String ip =dis.readUTF();
		lblConnectedTo.setText("Connected to IPv4 Address: " + ip);
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		frame.getContentPane().add(lblConnectedTo);
	}

	private static void controlServer() {
		try {
			socket = new Socket("localhost", 5000);
//			DataInputStream dis = new DataInputStream(socket.getInputStream());
//			String ip =dis.readUTF();
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

	}
}

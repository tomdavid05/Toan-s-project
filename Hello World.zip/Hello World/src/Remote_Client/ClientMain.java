package Remote_Client;

import javax.swing.UIManager;

public class ClientMain {

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			new ViewClient();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}

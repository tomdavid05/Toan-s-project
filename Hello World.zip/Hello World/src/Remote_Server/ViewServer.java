package Remote_Server;

import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Base64;
import java.util.Enumeration;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class ViewServer {

	private static ServerSocket serverSocket;
	private static DataInputStream dis;
	private JFrame frame;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					ViewServer window = new ViewServer();
//getIpV4();
					System.out.println("server is opening");
					serverSocket = new ServerSocket(5000);
					while (true) {
						Socket socket = serverSocket.accept();
						sendIpV4(socket);
						Thread thread = new Thread(() -> remoteServer(socket));
						thread.start();

					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ViewServer() {
		initialize();
//		openServer();

	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		this.frame.setVisible(true);
	}

//	public static void openServer() {
//		try {
//
//			System.out.println("server is opening");
//			serverSocket = new ServerSocket(5000);
//			while (true) {
//				Socket socket = serverSocket.accept();
//
//				remoteServer(socket);
////				dis.close();
////
////				socket.close();
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

	private static void remoteServer(Socket socket) {
		try {
			dis = new DataInputStream(socket.getInputStream());

			String cmd = dis.readUTF();
			while (true) {
				if (cmd.equalsIgnoreCase("shutdown")) {
					Runtime.getRuntime().exec("shutdown -s -t 3");
				} else if (cmd.equalsIgnoreCase("restart")) {
					Runtime.getRuntime().exec("shutdown -r -t 3");
				} else if (cmd.equalsIgnoreCase("cancel")) {
					Runtime.getRuntime().exec("shutdown -a");
				} else if (cmd.equalsIgnoreCase("screenshot")) {
					BufferedImage bi = new Robot()
							.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ImageIO.write(bi, "png", baos);
//				String base64Image = Base64.getEncoder().encodeToString(baos.toByteArray());
					DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

					byte[] imageBytes = baos.toByteArray();
					dos.writeInt(imageBytes.length);
					dos.write(imageBytes);
					dos.flush();
//				String x = Base64.getEncoder().encodeToString(imageBytes);
//				baos.close();
//				PrintWriter writer = new PrintWriter(socket.getOutputStream());
//				writer.println(imageBytes.length);
//				writer.flush();
//				socket.getOutputStream().write(imageBytes);

				}
//			dis.close();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private static void sendIpV4(Socket socket) throws IOException {
		String s = "";

		try {
			Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
			while (networkInterfaces.hasMoreElements()) {
				NetworkInterface networkInterface = networkInterfaces.nextElement();
				Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();

				while (inetAddresses.hasMoreElements()) {
					InetAddress inetAddress = inetAddresses.nextElement();
					if (inetAddress instanceof Inet4Address && !inetAddress.isLoopbackAddress()) {
						System.out.println("IPv4: " + inetAddress.getHostAddress());
						s = inetAddress.getHostAddress();
					}
				}
			}
			DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
			dos.writeUTF(s);
		} catch (SocketException e) {
			e.printStackTrace();
		}
		
	}

}
